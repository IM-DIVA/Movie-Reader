Page({
	onTap: function () {
		wx.switchTab({
			url: "../posts/post"
		})
	}
})